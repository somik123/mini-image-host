<?php

$protocol = getenv("APP_PROTOCOL") ?: "https://";
$domain   = getenv("APP_DOMAIN") ?: "example.com";

$image_path = getenv("IMAGE_PATH") ?: "./i/";
$image_url  = getenv("IMAGE_URL")  ?: "/i/";

$thumb_path = getenv("THUMB_PATH") ?: "./t/";
$thumb_url  = getenv("THUMB_URL")  ?: "/t/";

// Mirror domains (optional)
$mirror_domains = getenv("MIRROR_DOMAINS"); // comma-separated list
$mirror_list = [ $domain => "" ]; // always include the main domain

if ($mirror_domains) {
    $mirrors = array_map("trim", explode(",", $mirror_domains));
    foreach ($mirrors as $mirror) {
        $mirror_list[$mirror] = $mirror;
    }
}

$max_file_size = intval(getenv("MAX_FILE_SIZE") ?: 25 * 1024 * 1024); // bytes
$max_image_size = intval(getenv("MAX_IMAGE_SIZE") ?: 800); // pixels

$allowed_types = explode(",", getenv("ALLOWED_TYPES") ?: "image/jpeg,image/png,image/gif,image/webp");
